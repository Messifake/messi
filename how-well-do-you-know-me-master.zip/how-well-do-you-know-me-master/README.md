# how-well-do-you-know-me
A quiz to analyse how well your friends know about you. Also to get their Instagram Credentials ;). Use this along with my instagram-phishing repo
